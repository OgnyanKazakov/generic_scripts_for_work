import base64
import hashlib
# pip uninstall pycrypto
# pip install pycryptodome
from Crypto.Cipher import AES


class Decryptor:
    def __init__(self):
        # v Resolve chetohme tezi Key-ove ot DB
        self.key = hashlib.sha256("ebiMuMamata".encode()).digest() 
        self.block_size = AES.block_size


    def _unpadding(self, byte_arr):
        return byte_arr[:-ord(byte_arr[len(byte_arr)-1:])]


    def decrypt(self, message):
        enc = base64.b64decode(message)
        iv = enc[:AES.block_size]
        cipher = AES.new(self.key, AES.MODE_CBC, iv)
        return self._unpadding(cipher.decrypt(enc[AES.block_size:])).decode('utf-8')




