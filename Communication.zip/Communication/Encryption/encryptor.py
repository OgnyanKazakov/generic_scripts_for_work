import base64
import hashlib

# pip uninstall pycrypto
# pip install pycryptodome
from Crypto import Random
from Crypto.Cipher import AES


class Encryptor:
    def __init__(self):
        # v Resolve chetohme tezi Key-ove ot DB
        self.key = hashlib.sha256("ebiMuMamata".encode()).digest() 
        print("key:", self.key)
        self.block_size = AES.block_size


    def _padding(self, byte_arr):
        return byte_arr + (self.block_size - len(byte_arr) % self.block_size) * chr(self.block_size - len(byte_arr) % self.block_size)


    def encrypt(self, message):
        raw = self._padding(message)
        iv = Random.new().read(self.block_size)
        cipher = AES.new(self.key, AES.MODE_CBC, iv)
        return base64.b64encode(iv + cipher.encrypt(raw.encode()))




