import os
import sys
import json
import socket

from Encryption.encryptor import Encryptor


class MessageSender:
    """
    Sender object. Create an object and use it's 'Send' method
    whenever a new message should be transmited.
    """

    def __init__(self, endpoint):
        self.is_communication_ok = False
        try:
            endpoint = endpoint.split(':')
        except Exception as ex:
            endpoint = ['localhost', '55444']

        self._server_address = (endpoint[0], int(endpoint[1]))
        self._socket_sender = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.reconnect()
        self.is_communication_ok = True
        self.end_bytes_sequence = "endOfMessage"
        self.encryptor = Encryptor()

        
    def reconnect(self):
        if self.is_communication_ok is False:
            self._socket_sender.connect(self._server_address)
            self.is_communication_ok = True


    def send(self, message: str):
        if self.is_communication_ok is True:
            try:
                encoded_msg = self.encryptor.encrypt(message)
                encoded_msg += self.end_bytes_sequence.encode()
                self._socket_sender.send(encoded_msg)
            except Exception as err:
                self.is_communication_ok = False
                raise Exception("Error in message communication: " + str(err))


if __name__ == "__main__":
    js = {
        "key1":"value1",
        "key2":"valu2"
    }
    json_message = json.dumps(js)
    sender = MessageSender("localhost:55444")
    sender.send(json_message)
    