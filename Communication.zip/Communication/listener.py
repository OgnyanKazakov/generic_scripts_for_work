import sys
import json
import socket
from time import sleep, time
from obsub import event
import threading

from Encryption.decryptor import Decryptor


class MessageListener:
    """
    Listener object. It's working on a background thread.
    Received messages can be observed by subscribing to the  'received_message_event' method
    with a handler with arguments 'MessageListener', 'message'

    Attributes:
        received_message_event: [event]. Subscribe in order to receive new messages
    """

    def __init__(self,
                 listener_port = None):
        self.end_bytes_sequence = "endOfMessage".encode()     
        self.thread = None

        self._socket_listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._socket_listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._socket_listener.bind(('', listener_port))
        self.decoder = Decryptor()


    @event
    def received_message_event(self, message):
        print("Received message: " + str(message))
        translated = self.decoder.decrypt(message)
        print("Decoded msg:", translated)
        js = json.loads(translated)
        print("Json:", js)


    def start_background_accept_thread(self, connection):
        thread = threading.Thread(target=self.background_accept_message, args=(connection,))
        thread.daemon = True
        thread.start()


    def background_accept_message(self, connection):
        try: 
            firstBytesArrived = False
            isFailedListening = False
            data = ''
            
            while True:
                try:
                    bytes_chunk = connection.recv(4096)
                    if firstBytesArrived is False:
                        data = (bytes_chunk)
                    else:
                        data += bytes_chunk

                    firstBytesArrived = True
                    if bytes_chunk.find(self.end_bytes_sequence) != -1:
                        break
                except Exception as ex:
                    pass
                
        except Exception as ex:
            isFailedListening = True

        finally:
            # Clean up the connection
            connection.close()

            if isFailedListening is False:
                self.received_message_event(data[:len(data) - len(self.end_bytes_sequence)])
            

    def _listen(self):
        """
        The listener logic behinf the MessageListener class
        Provides support of both KAFKA and SOCKET communication types.
        """
        # Do not allow an exception to break listening
        while True:
            try:
                self._socket_listener.listen()
                print("Listening....")
                while True:
                    connection, client_address = self._socket_listener.accept()
                    self.start_background_accept_thread(connection)
            
            except Exception as ex:
                print("exception occuredd: " + str(ex))
                sleep(1)

        
    def Listen(self):
        """
        Creates a background thread which is listening for a new messages.
        """
        self.thread = threading.Thread(target=self._listen, args=())
        self.thread.daemon = True
        self.thread.start()


# place this function wherever you want to process your message - and register to it in order to receive messages.
def message_event(MessageListener, message):
    print("...")


if __name__ == "__main__":
    listener = MessageListener(listener_port=55444)
    listener.received_message_event += message_event
    listener.Listen()
    while True:
        sleep(1)