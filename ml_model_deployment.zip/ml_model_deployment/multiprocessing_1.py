import time
import multiprocessing
import concurrent.futures

def useless_function(sec = 1):
    print(f'Sleeping for {sec} second(s)')
    time.sleep(sec)
    print(f'Done sleeping')



if __name__ == "__main__":

    start = time.perf_counter()
    useless_function()
    useless_function()
    end = time.perf_counter()
    print(f'Finished in {round(end-start, 2)} second(s)')

    start = time.perf_counter()
    # process1 = multiprocessing.Process(target=useless_function)
    # process2 = multiprocessing.Process(target=useless_function)
    # process1.start()
    # process2.start()
    # end = time.perf_counter()
    # print(f'Finished in {round(end-start, 2)} second(s)')

    ## ProcessPoolExecutor
    # with concurrent.futures.ProcessPoolExecutor() as executor:
    #     process1 = executor.submit(useless_function, 1)
    #     process2 = executor.submit(useless_function, 1)
    #     print(f'Return Value: {process1.result()}')
    #     print(f'Return Value: {process2.result()}')
    # end = time.perf_counter()
    # print(f'Finished in {round(end-start, 2)} second(s)')

    # with concurrent.futures.ProcessPoolExecutor() as executor:
    #     secs = [5, 4, 3, 2, 1]
    #     pool = [executor.submit(useless_function, i) for i in secs]
    #     for i in concurrent.futures.as_completed(pool):
    #         print(f'Return Value: {i.result()}')
    # end = time.perf_counter()
    # print(f'Finished in {round(end-start, 2)} second(s)')


    # using map insead of string
    start = time.perf_counter()
    with concurrent.futures.ProcessPoolExecutor() as executor:
        secs = [5, 4, 3, 2, 1]
        pool = executor.map(useless_function, secs)
        for res in pool:
            print(f'Return Value: {res}')
    end = time.perf_counter()
    print(f'Finished in {round(end-start, 2)} second(s)')

